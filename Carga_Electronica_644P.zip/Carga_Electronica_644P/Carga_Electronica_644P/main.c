#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <avr/interrupt.h>
#include <stdbool.h>

#include "SPI/SPI.h"
#include "ADC/ADC.h"
#include "DAC/DAC.h"

float valor = 0.0;
volatile bool drdy = false;

Datos ADC_READ;

int main(void)
{
	cli();
	PCICR |= (1 << PCIE3);			// Pcint31....24  (P�g. 62) PD6 - PCINT30
	PCIFR |= (1 << PCIF3);			// Habilita la flag P�g. 62
	PCMSK3 |= (1 << PCINT30);		// Pcint 30 (P�g. 63)
	sei();
	spi_Start();
	_delay_us(100);
	ADC_start();
	DAC_Start();
	
	while (1) {
				
/*		
		for (uint8_t i = 0; i <= 200; i+= 20)
		{
			DAC_Set(i);
			Get_Data(&ADC_READ);
			float tension = ADC_READ.Tension;
			asm("nop");			
		}
*/

		if (drdy == true)
		{
			Get_Data(&ADC_READ);
			// ADC_READ.Tension;
			drdy = false;
			//asm("nop");	
		}

	}
}


ISR(PCINT3_vect)
{
	// if ( (PIND & (1 << PD6)) == (1 << PD6) )		// Trigger high
	if ( !((PIND & (1 << PD6))  >> PD6) )			// Trigger low
	{
		drdy = true;
	}
}