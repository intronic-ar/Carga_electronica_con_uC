/*
 * DAC.h
 *
 * Created: 18/3/2024 14:37:41
 *  Author: Fernando
 */ 


#ifndef DAC_H_
#define DAC_H_
#include <stdint.h>

void DAC_Set(uint16_t set);
void DAC_Start();


#endif /* DAC_H_ */