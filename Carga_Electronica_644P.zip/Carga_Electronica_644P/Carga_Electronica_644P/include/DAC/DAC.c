#include "DAC/DAC.h"
#include <avr/io.h>
#include <util/delay.h>
#include "SPI/SPI.h"

void DAC_Start()
{
	DDRD |= (1 << DDD7); // Salidas ( SS )
	_delay_us(50);
	PORTD &= ~(1 << PD7);		// LOW SS
	spi_Transfer(0b00111000);	// Habilita REF interna
	spi_Transfer(0xFF);			// Basura
	spi_Transfer(0xFF);			// Basura
	PORTD |= (1 << PD7);		// HIGH SS
	_delay_us(100);
}


void DAC_Set(uint16_t set)
{
	uint8_t _DACout[2];
	_DACout[0] = (set >> 8);
	_DACout[1] = (set);
	
	PORTD &= ~(1 << PD7);		// LOW SS
	spi_Transfer(0x00);	
	spi_Transfer(_DACout[0]);
	spi_Transfer(_DACout[1]);			
	PORTD |= (1 << PD7);		// HIGH SS
	
	
}