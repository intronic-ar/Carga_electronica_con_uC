/*
 * SPI.h
 *
 * Created: 17/3/2024 17:05:27
 *  Author: Fernando
 */ 


#ifndef SPI_H_
#define SPI_H_
#include <avr/io.h>

void spi_Start();

uint8_t spi_Transfer(uint8_t datos);

#endif /* SPI_H_ */