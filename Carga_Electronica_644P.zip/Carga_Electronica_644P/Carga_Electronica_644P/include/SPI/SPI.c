/*
 * SPI.c
 *
 * Created: 17/3/2024 17:05:54
 *  Author: Fernando
 */ 


#include "SPI.h"


void spi_Start()
{

	// Definimos pines:

	DDRB |= (1 << DDB4) | (1 << DDB5) | (1 << DDB7); // Salidas (MOSI, SCK, SS )
	DDRB &= ~(1 << DDB6);                            // Entradas (MISO)
	PORTB |= (1 << PB4);                             // HIGH SS
	SPCR = 0b01010101;  // Master, 1 MHz, Modo = 1,
}

uint8_t spi_Transfer(uint8_t datos)
{
	SPDR = datos;
	//	while (!(SPSR & (1 << SPIF)));	//Escribo al SPI
	while (!(SPSR & _BV(SPIF)));
	return SPDR;
}
