
#ifndef ADC_H_
#define ADC_H_

typedef struct
{
	float Tension;
	float Corriente;
} Datos;

void Get_Data(Datos *_datos);
void ADC_start();

#endif /* ADC_H_ */