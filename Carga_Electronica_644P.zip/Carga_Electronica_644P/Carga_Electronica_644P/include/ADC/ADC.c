#include "ADC/ADC.h"
#include <avr/io.h>
#include <util/delay.h>
#include "SPI/SPI.h"

float promedio = 0.0;
float lectura;
uint8_t n = 0;

void Get_Data(Datos *_datos)
{
	
	PORTB &= ~(1 << PB4);		// LOW SS
	uint8_t highByte = spi_Transfer(0x00);
	uint8_t lowByte = spi_Transfer(0x00);
	PORTB |= (1 << PB4);		// HIGH SS
		
	uint16_t data = highByte;
	data <<= 8;
	data |= lowByte;

	uint8_t signo = (highByte >> 7);

	if (signo == 1)
	{
		data = ~data + 1;
		lectura = data * (-2.048) / 32767.0;
	}
	else
	{
		lectura = data * 2.048 / 32767.0;
	}

	if (n < 5)
	{
		promedio += lectura / 5.0;
		n ++;		
	} 
	else
	{
		n = 0;
		_datos -> Tension = promedio;
		promedio = 0.0;
		asm("nop");	
	}
				
}

void ADC_start()
{
	DDRD &= ~(1 << DDD6);		// DRDY input
	
	PORTB &= ~(1 << PB4);		// LOW SS
	spi_Transfer(0b01000001);
	spi_Transfer(0b00000000);	// 0b01010000 = MUX: AINP = AIN2, AINN = AIN3 o 0b00000000 = MUX: AINP = AIN0, AINN = AIN1 
	spi_Transfer(0x00);
	PORTB |= (1 << PB4);		// HIGH SS
	_delay_us(100);

	PORTB &= ~(1 << PB4);		// LOW SS
	spi_Transfer(0b01001001);
	spi_Transfer(0b00100000);	// FIR: 50-Hz rejection only
	spi_Transfer(0x00);
	PORTB |= (1 << PB4);		// HIGH SS
	_delay_us(100);


	PORTB &= ~(1 << PB4);		// LOW SS
	spi_Transfer(0b01000101);
	spi_Transfer(0b00100100);	// 45 SPS, : Continuous conversion mode
	spi_Transfer(0x00);
	PORTB |= (1 << PB4);		// HIGH SS
	_delay_us(100);

	spi_Transfer(0b00001000);	// START/SYNC
}

  /*
  WREG (0100 rrnn)
  The WREG command writes the number of bytes specified by nn (number of bytes to be written � 1) to the
  device configuration register, starting at register address rr. The command is completed after nn + 1 bytes are
  clocked in after the WREG command byte. For example, the command to write two bytes (nn = 01) starting at
  configuration register 0 (rr = 00) is 0100 0001. The configuration registers are updated on the last SCLK falling
  */
